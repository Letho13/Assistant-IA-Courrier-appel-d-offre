# Assistant ADV

Prototype Streamlit qui analyse un courrier client et rédige un brouillon de réponse avec un modèle servi localement par Ollama. Les prix, délais, remises et engagements ne doivent pas être inventés ; le brouillon doit être relu et validé avant envoi.

## Démonstration d'entretien

Le projet comprend un exemple de courrier fictif et un résultat de démonstration préchargé. Le bouton **Afficher le résultat de démonstration** montre le parcours sans installer ni démarrer Ollama. Ce résultat est préparé à l'avance et clairement signalé comme illustratif ; il ne faut pas le présenter comme une génération en direct.

Sur un PC Windows avec Python 3 et un accès Internet pour installer les dépendances :

1. Copie le dossier du projet sur le PC (ou une clé USB), sans copier le dossier `.venv`.
2. Double-clique sur `Lancer la démo.bat`.
3. Dans le navigateur, ouvre `http://localhost:8501`, puis présente l'exemple et son résultat.

Le premier démarrage crée un environnement Python local et installe Streamlit et Requests. Pour montrer une génération réelle, Ollama et un modèle compatible doivent aussi être installés sur le PC ; ils ne sont pas nécessaires pour le résultat préchargé. L'application et le modèle s'exécutent localement. Ce projet n'est pas un site public hébergé et le dossier ne contient pas un runtime Python autonome.

### Présentation en entretien

Pitch possible : « J'ai prototypé un assistant ADV pour qualifier des demandes de cotation de transport alimentaire. Il repère les contraintes d'expédition, signale les vérifications manquantes, distingue les faits des calculs et prépare un brouillon sans inventer de prix ni de délai garanti. L'ADV garde la validation finale. »

Déroulé court : présente le parcours en trois étapes, montre les champs détectés et le calcul de 400 kg par palette, puis affiche le brouillon préchargé. Précise qu'il s'agit d'un prototype : le résultat préchargé n'est pas généré en direct, les e-mails et pièces jointes ne sont pas importés automatiquement, et l'intégration aux tarifs réels reste à faire.

## Contrôles des demandes de transport

L'exemple fourni concerne du transport alimentaire sous température dirigée. L'analyse relève la marchandise et sa température, le conditionnement et les dimensions des palettes, leur gerbabilité, le poids total et moyen (calculé si le poids total et le nombre de palettes sont connus), les lieux de chargement et de livraison, la fréquence et la date de démarrage, les contraintes de hayon et de rendez-vous, ainsi que le délai garanti demandé, les champs entre crochets à compléter et la date limite de l'offre. Le brouillon répond du point de vue du transporteur et ne doit pas transformer une demande de cotation en offre validée.

Elle conserve également les contrôles tarifaires ADV : tarif au voyage, à la tonne ou à la palette ; forfaitaire ou unitaire (sans déduire cette nature de l'unité) ; grille tarifaire jointe ; indexation CNR et parts gazole/GNR ; massification, ouverture de portes ; traction, distribution ou bout en bout ; hauteur et poids moyen des palettes. Un tableau de repérage par mots-clés montre les extraits trouvés ; une absence de détection ne prouve pas que l'information est absente et doit être vérifiée.

L'application n'est pas connectée à une messagerie et ne lit pas les fichiers joints. La zone « Pièces jointes repérées » permet de communiquer manuellement un nom ou une description ; elle ne permet pas d'analyser le contenu d'une grille tarifaire. Le modèle ne doit donc pas prétendre avoir ouvert ou vérifié un fichier.

## Démarrage

1. Installe Ollama depuis [ollama.com](https://ollama.com/) et démarre-le.
2. Télécharge un modèle, par exemple :

   ```powershell
   ollama pull llama3.2
   ```

3. Installe les dépendances Python et lance l'application :

   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   streamlit run app.py
   ```

L'application utilise par défaut l'API Ollama à `http://localhost:11434` et affiche les modèles installés dans le panneau latéral. Elle n'active pas la génération tant qu'aucun modèle local n'est disponible. Si Ollama ne répond pas, l'application affiche une erreur au lieu de produire une réponse fictive.
